Stock Card Report is the report that display movement (in/out) of a product in a specified location and date range.
